const express = require("express");
const mongoose = require("mongoose");

const Student = require("./Models/Student");

const app = express();

app.use(express.json());

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/studentDB")
    .then(() => {
        console.log("MongoDB connected successfully");
    })
    .catch((error) => {
        console.log("MongoDB connection error:", error);
    });

// Add a new student
app.post("/students", async (req, res) => {
    try {
        const student = new Student(req.body);
        const savedStudent = await student.save();

        res.status(201).json(savedStudent);
    } catch (error) {
        res.status(400).json({
            error: error.message
        });
    }
});

// Retrieve all students
app.get("/students", async (req, res) => {
    try {
        const students = await Student.find();

        res.json(students);
    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
});

// Search students by department
app.get("/students/department/:department", async (req, res) => {
    try {
        const students = await Student.find({
            department: req.params.department
        });

        res.json(students);
    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
});

// Sort students by CGPA
app.get("/students/sort/cgpa", async (req, res) => {
    try {
        const students = await Student.find().sort({
            cgpa: -1
        });

        res.json(students);
    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
});

// Retrieve one student by Student ID
app.get("/students/:studentId", async (req, res) => {
    try {
        const student = await Student.findOne({
            studentId: req.params.studentId
        });

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            });
        }

        res.json(student);
    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
});

// Update student
app.put("/students/:studentId", async (req, res) => {
    try {
        const student = await Student.findOneAndUpdate(
            { studentId: req.params.studentId },
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            });
        }

        res.json(student);
    } catch (error) {
        res.status(400).json({
            error: error.message
        });
    }
});

// Delete student
app.delete("/students/:studentId", async (req, res) => {
    try {
        const student = await Student.findOneAndDelete({
            studentId: req.params.studentId
        });

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            });
        }

        res.json({
            message: "Student deleted successfully"
        });
    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
});
app.get("/students/count/total", async (req, res) => {
    try {
        const count = await Student.countDocuments();

        res.json({
            totalStudents: count
        });
    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
});
// Start server
app.listen(3000, () => {
    console.log("Server running on port 3000");
});