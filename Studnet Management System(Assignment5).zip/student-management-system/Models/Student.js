const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
    studentId: {
        type: String,
        required: true,
        unique: true
    },

    studentName: {
        type: String,
        required: true
    },

    department: {
        type: String,
        required: true
    },

    email: {
        type: String,
        required: true,
        match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    },

    cgpa: {
        type: Number,
        required: true,
        min: 0,
        max: 10
    }
});

const Student = mongoose.model("Student", studentSchema);

module.exports = Student;