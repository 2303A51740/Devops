const express = require("express");
const jwt = require("jsonwebtoken");

const app = express();

const PORT = 3000;
const SECRET_KEY = "student_secret_key";

app.use(express.json());

const users = [];

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers["authorization"];

    if (!authHeader) {
        return res.status(401).json({
            message: "Access denied. Token required."
        });
    }

    const token = authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            message: "Access denied. Token required."
        });
    }

    try {
        const user = jwt.verify(token, SECRET_KEY);
        req.user = user;
        next();
    } catch (error) {
        return res.status(401).json({
            message: "Invalid or expired token"
        });
    }
};

const students = [
    {
        id: 1,
        name: "Rahul",
        age: 20,
        course: "Computer Science"
    },
    {
        id: 2,
        name: "Priya",
        age: 21,
        course: "Artificial Intelligence"
    }
];

app.get("/", (req, res) => {
    res.json({
        message: "Welcome to Secure Student API"
    });
});

app.post("/register", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            message: "Username and password are required"
        });
    }

    const existingUser = users.find(user => user.username === username);

    if (existingUser) {
        return res.status(400).json({
            message: "User already exists"
        });
    }

    const user = {
        id: users.length + 1,
        username: username,
        password: password,
        role: "student"
    };

    users.push(user);

    res.status(201).json({
        message: "User registered successfully",
        user: {
            id: user.id,
            username: user.username,
            role: user.role
        }
    });
});

app.post("/login", (req, res) => {
    const { username, password } = req.body;

    const user = users.find(
        user => user.username === username && user.password === password
    );

    if (!user) {
        return res.status(401).json({
            message: "Invalid username or password"
        });
    }

    const token = jwt.sign(
        {
            userId: user.id,
            username: user.username,
            role: user.role
        },
        SECRET_KEY,
        {
            expiresIn: "1h"
        }
    );

    res.json({
        message: "Login successful",
        token: token
    });
});

app.get("/students", authenticateToken, (req, res) => {
    res.json({
        message: "Students retrieved successfully",
        students: students
    });
});

app.post("/students", authenticateToken, (req, res) => {
    const { name, age, course } = req.body;

    if (!name || !age || !course) {
        return res.status(400).json({
            message: "Name, age and course are required"
        });
        app.get("/students/:id", authenticateToken, (req, res) => {
    const id = parseInt(req.params.id);

    const student = students.find(student => student.id === id);

    if (!student) {
        return res.status(404).json({
            message: "Student not found"
        });
    }

    res.json({
        message: "Student retrieved successfully",
        student: student
    });
});
    }


    const student = {
        id: students.length + 1,
        name: name,
        age: age,
        course: course
    };

    students.push(student);

    res.status(201).json({
        message: "Student added successfully",
        student: student
    });
});

app.get("/students/:id", authenticateToken, (req, res) => {
    const id = parseInt(req.params.id);

    const student = students.find(student => student.id === id);

    if (!student) {
        return res.status(404).json({
            message: "Student not found"
        });
    }

    res.json(student);
});

app.use((req, res) => {
    res.status(404).json({
        message: "Route not found"
    });
});
app.use((req, res) => {
    res.status(404).json({
        message: "Route not found"
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});