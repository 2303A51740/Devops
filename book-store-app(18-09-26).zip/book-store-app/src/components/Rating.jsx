function Rating({ rating }) {
  return (
    <p>
      Rating: ⭐ {rating}/5
    </p>
  );
}

export default Rating;