import Rating from "./Rating";

function BookCard({ book }) {
  return (
    <div className="book-card">
      <h2>{book.title}</h2>

      <p>
        <strong>Author:</strong> {book.author}
      </p>

      <p>
        <strong>Price:</strong> ₹{book.price}
      </p>

      <p>
        <strong>Category:</strong> {book.category}
      </p>

      <Rating rating={book.rating} />

      <button>Buy Now</button>

      <button>View Details</button>
    </div>
  );
}

export default BookCard;