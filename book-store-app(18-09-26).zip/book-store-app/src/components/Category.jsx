function Category() {
  return (
    <div className="categories">
      <h2>Book Categories</h2>

      <div>
        <span>Programming</span>
        <span>Fiction</span>
        <span>Science</span>
        <span>Business</span>
      </div>
    </div>
  );
}

export default Category;