function Footer() {
  return (
    <footer>
      <p>© 2026 Online Book Store</p>
      <p>Your favourite books in one place.</p>
    </footer>
  );
}

export default Footer;