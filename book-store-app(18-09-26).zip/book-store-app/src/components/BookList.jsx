import BookCard from "./BookCard";

function BookList({ books }) {
  return (
    <div>
      <h2 className="section-title">Available Books</h2>

      {books.length > 0 ? (
        <>
          <p className="found">Book Found</p>

          <div className="book-list">
            {books.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </>
      ) : (
        <p className="not-found">No Books Found</p>
      )}
    </div>
  );
}

export default BookList;