function Header() {
  return (
    <header>
      <h1>📚 Online Book Store</h1>

      <nav>
        <a href="#">Home</a>
        <a href="#">Books</a>
        <a href="#">Categories</a>
        <a href="#">About</a>
      </nav>
    </header>
  );
}

export default Header;