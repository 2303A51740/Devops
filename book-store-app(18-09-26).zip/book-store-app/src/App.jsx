import { useState } from "react";
import "./App.css";

import Header from "./components/Header";
import SearchBar from "./components/SearchBar";
import Category from "./components/Category";
import BookList from "./components/BookList";
import Footer from "./components/Footer";

function App() {
  const [search, setSearch] = useState("");

  const books = [
    {
      id: 1,
      title: "React for Beginners",
      author: "John Smith",
      price: 499,
      category: "Programming",
      rating: 4.5,
    },
    {
      id: 2,
      title: "JavaScript Essentials",
      author: "David Brown",
      price: 399,
      category: "Business",
      rating: 4.2,
    },
    {
      id: 3,
      title: "The Mystery House",
      author: "Emma Wilson",
      price: 299,
      category: "Fiction",
      rating: 4.0,
    },
    {
      id: 4,
      title: "Science of Space",
      author: "Robert James",
      price: 599,
      category: "Science",
      rating: 4.8,
    },
  ];

  const filteredBooks = books.filter((book) =>
    book.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <Header />

      <main>
        <h1 className="welcome">
          Welcome to Online Book Store
        </h1>

        <SearchBar search={search} setSearch={setSearch} />

        <Category />

        <BookList books={filteredBooks} />
      </main>

      <Footer />
    </>
  );
}

export default App;