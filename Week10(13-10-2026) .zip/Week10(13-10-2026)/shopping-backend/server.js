
const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

let products = [
    { id: 1, name: "Laptop", category: "Electronics", price: 60000 },
    { id: 2, name: "Headphones", category: "Electronics", price: 2000 },
    { id: 3, name: "Backpack", category: "Accessories", price: 1500 }
];

let nextId = 4;

function isValidProduct(body) {
    return body &&
        typeof body.name === "string" &&
        typeof body.category === "string" &&
        body.name.trim().length > 0 &&
        body.name.trim().length <= 80 &&
        body.category.trim().length > 0 &&
        body.category.trim().length <= 50 &&
        body.price !== "" &&
        Number.isFinite(Number(body.price)) &&
        Number(body.price) >= 0;
}

function findProductId(id) {
    const productId = Number(id);
    return Number.isInteger(productId) && productId > 0 ? productId : null;
}

app.get("/api/products", (req, res) => {
    res.json(products);
});

app.get("/api/products/:id", (req, res) => {
    const id = findProductId(req.params.id);
    const product = products.find(p => p.id === id);

    if (!product) {
        return res.status(404).json({ message: "Product not found" });
    }

    res.json(product);
});
app.post("/api/products", (req, res) => {
    if (!isValidProduct(req.body)) {
        return res.status(400).json({ message: "Valid product details are required" });
    }

    const { name, category, price } = req.body;
    const product = {
        id: nextId++,
        name: name.trim(),
        category: category.trim(),
        price: Number(price)
    };

    products.push(product);
    res.status(201).json(product);
});

app.put("/api/products/:id", (req, res) => {
    const id = findProductId(req.params.id);
    const product = products.find(p => p.id === id);

    if (!product) {
        return res.status(404).json({ message: "Product not found" });
    }

    if (!isValidProduct(req.body)) {
        return res.status(400).json({ message: "Valid product details are required" });
    }

    const { name, category, price } = req.body;
    product.name = name.trim();
    product.category = category.trim();
    product.price = Number(price);

    res.json(product);
});

app.delete("/api/products/:id", (req, res) => {
    const id = findProductId(req.params.id);
    const index = products.findIndex(p => p.id === id);

    if (index === -1) {
        return res.status(404).json({ message: "Product not found" });
    }

    products.splice(index, 1);
    res.json({ message: "Product deleted successfully" });
});

app.get("/", (req, res) => {
    res.send("Shopping Backend API is running");
});

app.use((error, req, res, next) => {
    if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
        return res.status(400).json({ message: "Request body must be valid JSON" });
    }

    console.error(error);
    return res.status(500).json({ message: "An unexpected server error occurred" });
});

const port = Number(process.env.PORT) || 5000;

app.listen(port, () => {
    console.log(`Backend running at http://localhost:${port}`);
});