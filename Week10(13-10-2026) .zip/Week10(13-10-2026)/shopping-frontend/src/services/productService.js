
import axios from "axios";

const API = `${import.meta.env.VITE_API_URL || "http://localhost:5000"}/api/products`;

export const getProducts = (config) => axios.get(API, config);

export const getProduct = (id, config) => axios.get(`${API}/${id}`, config);

export const addProduct = (product) => axios.post(API, product);

export const updateProduct = (id, product) =>
    axios.put(`${API}/${id}`, product);

export const deleteProduct = (id) => axios.delete(`${API}/${id}`);