
function SearchBar({ filters, categories, onChange }) {
    return (
        <div className="filter-panel">
            <label className="search-field">
                <span className="search-icon" aria-hidden="true">⌕</span>
                <span className="visually-hidden">Search by product or category</span>
                <input
                    type="search"
                    placeholder="Find your next favorite..."
                    value={filters.search}
                    onChange={event => onChange({ search: event.target.value })}
                />
                <kbd>/</kbd>
            </label>
            <div className="filter-controls">
                <label>
                    <span className="visually-hidden">Category</span>
                    <select
                        value={filters.category}
                        onChange={event => onChange({ category: event.target.value })}
                    >
                        <option>All categories</option>
                        {categories.map(category => <option key={category}>{category}</option>)}
                    </select>
                </label>
                <label className="range-field">
                    <span className="visually-hidden">Minimum price</span>
                    <span>₹</span>
                    <input
                        type="number"
                        min="0"
                        placeholder="Min"
                        value={filters.minPrice}
                        onChange={event => onChange({ minPrice: event.target.value })}
                    />
                </label>
                <span className="range-divider">—</span>
                <label className="range-field">
                    <span className="visually-hidden">Maximum price</span>
                    <span>₹</span>
                    <input
                        type="number"
                        min="0"
                        placeholder="Max"
                        value={filters.maxPrice}
                        onChange={event => onChange({ maxPrice: event.target.value })}
                    />
                </label>
                <label>
                    <span className="visually-hidden">Sort products</span>
                    <select
                        value={filters.sort}
                        onChange={event => onChange({ sort: event.target.value })}
                    >
                        <option value="featured">Featured</option>
                        <option value="price-low">Price: low to high</option>
                        <option value="price-high">Price: high to low</option>
                        <option value="name">Name: A to Z</option>
                    </select>
                </label>
            </div>
        </div>
    );
}

export default SearchBar;