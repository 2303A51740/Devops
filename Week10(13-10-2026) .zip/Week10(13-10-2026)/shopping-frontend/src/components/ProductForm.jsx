
import { useState } from "react";

function ProductForm({ selectedProduct, onSave, onCancel, saving }) {
    const [name, setName] = useState(selectedProduct?.name ?? "");
    const [category, setCategory] = useState(selectedProduct?.category ?? "");
    const [price, setPrice] = useState(selectedProduct?.price ?? "");
    const [validationError, setValidationError] = useState("");

    function handleSubmit(e) {
        e.preventDefault();

        if (!name.trim() || !category.trim()) {
            setValidationError("Product name and category are required.");
            return;
        }
        if (price === "" || !Number.isFinite(Number(price)) || Number(price) < 0) {
            setValidationError("Enter a valid, non-negative price.");
            return;
        }

        setValidationError("");
        onSave({
            name: name.trim(),
            category: category.trim(),
            price: Number(price)
        });
    }

    return (
        <form className="product-form" onSubmit={handleSubmit}>
            <p className="form-intro">
                {selectedProduct
                    ? "A small refresh to make this one just right."
                    : "What deserves a spot on the shelf?"}
            </p>

            <label htmlFor="product-name">PRODUCT NAME</label>
            <input
                id="product-name"
                placeholder="e.g. Sunday headphones"
                value={name}
                onChange={e => setName(e.target.value)}
                maxLength="80"
                required
            />

            <label htmlFor="product-category">CATEGORY</label>
            <input
                id="product-category"
                placeholder="e.g. Everyday tech"
                value={category}
                onChange={e => setCategory(e.target.value)}
                maxLength="50"
                required
            />

            <label htmlFor="product-price">PRICE <span>IN RUPEES</span></label>
            <div className="price-input-wrap">
                <span aria-hidden="true">₹</span>
                <input
                    id="product-price"
                    type="number"
                    placeholder="0"
                    min="0"
                    step="0.01"
                    value={price}
                    onChange={e => setPrice(e.target.value)}
                    required
                />
            </div>

            {validationError && <p className="form-error" role="alert">{validationError}</p>}

            <button className="submit-button" type="submit" disabled={saving}>
                {saving ? "Saving..." : selectedProduct ? "Save changes" : "Add to the collection"}
                {!saving && <span aria-hidden="true">↗</span>}
            </button>

            {selectedProduct && (
                <button className="cancel-button" type="button" onClick={onCancel} disabled={saving}>
                    Cancel editing
                </button>
            )}
        </form>
    );
}

export default ProductForm;