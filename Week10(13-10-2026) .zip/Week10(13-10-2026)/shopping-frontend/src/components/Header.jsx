
function Header({ cartCount, onCartClick }) {
    return (
        <header className="site-header">
            <a className="brand" href="/" aria-label="Fieldnotes Market home">
                <span className="brand-mark">f.</span>
                <span>FIELDNOTES <small>MARKET</small></span>
            </a>
            <span className="header-note">A GOOD DAY TO FIND SOMETHING GOOD</span>
            <button className="basket-button" onClick={onCartClick}>
                YOUR BASKET <span className="basket-count">{cartCount}</span>
            </button>
        </header>
    );
}

export default Header;