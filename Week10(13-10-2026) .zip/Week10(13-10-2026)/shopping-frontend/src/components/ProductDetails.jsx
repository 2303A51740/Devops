
function ProductDetails({ product, loading, onClose, onAddToCart }) {
    if (!product && !loading) return null;

    return (
        <div className="modal-backdrop" onClick={onClose}>
            <section
                className="product-details"
                role="dialog"
                aria-modal="true"
                aria-labelledby="detail-title"
                onClick={event => event.stopPropagation()}
            >
                <button className="close-button detail-close" onClick={onClose} aria-label="Close details">×</button>
                {loading ? (
                    <div className="detail-loading" role="status">Finding the details...</div>
                ) : (
                    <>
                        <div className="detail-art"><span>{product.name.slice(0, 1).toUpperCase()}</span></div>
                        <div className="detail-copy">
                            <span className="eyebrow">{product.category} · FIELDNOTES PICK</span>
                            <h2 id="detail-title">{product.name}</h2>
                            <p className="detail-description">A thoughtful find for the everyday. Consider this one a little upgrade to the ordinary.</p>
                            <strong className="detail-price">₹{Number(product.price).toLocaleString("en-IN")}</strong>
                            <button className="submit-button" onClick={() => onAddToCart(product)}>
                                Add to your basket <span aria-hidden="true">↗</span>
                            </button>
                        </div>
                    </>
                )}
            </section>
        </div>
    );
}

export default ProductDetails;