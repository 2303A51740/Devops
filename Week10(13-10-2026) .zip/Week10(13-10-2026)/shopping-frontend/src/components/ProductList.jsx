
import ProductCard from "./ProductCard";

function ProductList({
    products,
    totalResults,
    onEdit,
    onDelete,
    onDetails,
    onAddToCart,
    page,
    pageCount,
    onPageChange
}) {
    if (totalResults === 0) {
        return (
            <div className="empty-state">
                <span aria-hidden="true">◌</span>
                <h3>Nothing on this shelf just yet.</h3>
                <p>Try a different search or loosen your filters.</p>
            </div>
        );
    }

    return (
        <>
            <div className="product-list">
                {products.map((product, index) => (
                    <ProductCard
                        key={product.id}
                        product={product}
                        index={index}
                        onEdit={onEdit}
                        onDelete={onDelete}
                        onDetails={onDetails}
                        onAddToCart={onAddToCart}
                    />
                ))}
            </div>
            {pageCount > 1 && (
                <nav className="pagination" aria-label="Product pages">
                    <span>{String((page - 1) * 6 + 1).padStart(2, "0")}—{String(Math.min(page * 6, totalResults)).padStart(2, "0")} OF {String(totalResults).padStart(2, "0")}</span>
                    <div>
                        <button onClick={() => onPageChange(page - 1)} disabled={page === 1} aria-label="Previous page">←</button>
                        <span>{String(page).padStart(2, "0")} / {String(pageCount).padStart(2, "0")}</span>
                        <button onClick={() => onPageChange(page + 1)} disabled={page === pageCount} aria-label="Next page">→</button>
                    </div>
                </nav>
            )}
        </>
    );
}

export default ProductList;