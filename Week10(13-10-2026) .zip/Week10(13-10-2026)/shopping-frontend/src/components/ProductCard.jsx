
function ProductCard({ product, index, onEdit, onDelete, onDetails, onAddToCart }) {
    const initials = product.name
        .split(/\s+/)
        .slice(0, 2)
        .map(word => word[0])
        .join("")
        .toUpperCase();

    return (
        <article className={`product-card product-card-${index % 4}`}>
            <div className="product-art">
                <span className="product-art-index">NO. {String(product.id).padStart(2, "0")}</span>
                <span className="product-initials" aria-hidden="true">{initials}</span>
                <button className="quick-add" onClick={() => onAddToCart(product)} aria-label={`Add ${product.name} to basket`}>+</button>
            </div>
            <div className="product-card-copy">
                <span className="product-category">{product.category}</span>
                <button className="product-title" onClick={() => onDetails(product.id)}>{product.name}</button>
                <div className="product-card-bottom">
                    <strong>₹{Number(product.price).toLocaleString("en-IN")}</strong>
                    <div className="product-actions">
                        <button onClick={() => onEdit(product)} aria-label={`Edit ${product.name}`}>Edit</button>
                        <button onClick={() => onDelete(product.id)} aria-label={`Delete ${product.name}`}>Remove</button>
                    </div>
                </div>
            </div>
        </article>
    );
}

export default ProductCard;