import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Header from "./components/Header";
import SearchBar from "./components/SearchBar";
import ProductList from "./components/ProductList";
import ProductForm from "./components/ProductForm";
import ProductDetails from "./components/ProductDetails";
import {
    getProducts,
    addProduct,
    updateProduct,
    deleteProduct,
    getProduct
} from "./services/productService";
import "./App.css";

const PAGE_SIZE = 6;
const initialFilters = {
    search: "",
    category: "All categories",
    minPrice: "",
    maxPrice: "",
    sort: "featured"
};

function App() {
    const [products, setProducts] = useState([]);
    const [filters, setFilters] = useState(initialFilters);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [details, setDetails] = useState(null);
    const [detailsLoading, setDetailsLoading] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [saving, setSaving] = useState(false);
    const [cart, setCart] = useState([]);
    const [cartOpen, setCartOpen] = useState(false);
    const [page, setPage] = useState(1);
    const detailsController = useRef(null);

    const loadProducts = useCallback(async (signal) => {
        setLoading(true);
        setError("");

        try {
            const response = await getProducts({ signal });
            setProducts(response.data);
        } catch {
            if (!signal?.aborted) {
                setError("Unable to load products. Please try again.");
            }
        } finally {
            if (!signal?.aborted) setLoading(false);
        }
    }, []);

    useEffect(() => {
        const controller = new AbortController();

        getProducts({ signal: controller.signal })
            .then(response => {
                setProducts(response.data);
                setError("");
            })
            .catch(() => {
                if (!controller.signal.aborted) {
                    setError("Unable to load products. Please try again.");
                }
            })
            .finally(() => {
                if (!controller.signal.aborted) setLoading(false);
            });

        return () => {
            controller.abort();
            detailsController.current?.abort();
        };
    }, []);

    const categories = useMemo(
        () => [...new Set(products.map(product => product.category))].sort(),
        [products]
    );

    const filteredProducts = useMemo(() => {
        const query = filters.search.trim().toLowerCase();
        const min = filters.minPrice === "" ? null : Number(filters.minPrice);
        const max = filters.maxPrice === "" ? null : Number(filters.maxPrice);
        const matching = products.filter(product => {
            const matchesQuery = !query ||
                `${product.name} ${product.category}`.toLowerCase().includes(query);
            const matchesCategory =
                filters.category === "All categories" ||
                product.category === filters.category;
            const matchesMin = min === null || product.price >= min;
            const matchesMax = max === null || product.price <= max;
            return matchesQuery && matchesCategory && matchesMin && matchesMax;
        });

        if (filters.sort === "price-low") return matching.sort((a, b) => a.price - b.price);
        if (filters.sort === "price-high") return matching.sort((a, b) => b.price - a.price);
        if (filters.sort === "name") {
            return matching.sort((a, b) => a.name.localeCompare(b.name));
        }
        return matching;
    }, [filters, products]);

    const pageCount = Math.max(1, Math.ceil(filteredProducts.length / PAGE_SIZE));
    const currentPage = Math.min(page, pageCount);
    const visibleProducts = filteredProducts.slice(
        (currentPage - 1) * PAGE_SIZE,
        currentPage * PAGE_SIZE
    );
    const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
    const cartProducts = cart
        .map(item => ({
            ...item,
            product: products.find(product => product.id === item.id)
        }))
        .filter(item => item.product);

    function updateFilters(changes) {
        setFilters(current => ({ ...current, ...changes }));
        setPage(1);
    }

    async function handleSave(product) {
        setSaving(true);
        setError("");

        try {
            if (selectedProduct) {
                const response = await updateProduct(selectedProduct.id, product);
                setProducts(current =>
                    current.map(item => item.id === selectedProduct.id ? response.data : item)
                );
                if (details?.id === selectedProduct.id) setDetails(response.data);
                setSelectedProduct(null);
            } else {
                const response = await addProduct(product);
                setProducts(current => [...current, response.data]);
                setPage(1);
            }
        } catch {
            setError("Unable to save product. Please check the details and try again.");
        } finally {
            setSaving(false);
        }
    }

    async function handleDelete(id) {
        if (!window.confirm("Remove this product from the collection?")) return;

        setError("");
        try {
            await deleteProduct(id);
            setProducts(current => current.filter(product => product.id !== id));
            setCart(current => current.filter(item => item.id !== id));
            if (details?.id === id) setDetails(null);
            if (selectedProduct?.id === id) setSelectedProduct(null);
        } catch {
            setError("Unable to delete product. Please try again.");
        }
    }

    async function handleDetails(id) {
        detailsController.current?.abort();
        const controller = new AbortController();
        detailsController.current = controller;
        setDetails(null);
        setDetailsLoading(true);
        setError("");

        try {
            const response = await getProduct(id, { signal: controller.signal });
            setDetails(response.data);
        } catch {
            if (!controller.signal.aborted) {
                setError("Unable to load product details. Please try again.");
            }
        } finally {
            if (!controller.signal.aborted) setDetailsLoading(false);
        }
    }

    function closeDetails() {
        detailsController.current?.abort();
        detailsController.current = null;
        setDetails(null);
        setDetailsLoading(false);
    }

    function addToCart(product) {
        setCart(current => {
            const existing = current.find(item => item.id === product.id);
            if (existing) {
                return current.map(item =>
                    item.id === product.id
                        ? { ...item, quantity: item.quantity + 1 }
                        : item
                );
            }
            return [...current, { id: product.id, quantity: 1 }];
        });
    }

    function changeCartQuantity(id, change) {
        setCart(current => current
            .map(item => item.id === id
                ? { ...item, quantity: item.quantity + change }
                : item)
            .filter(item => item.quantity > 0));
    }

    const cartTotal = cartProducts.reduce(
        (total, item) => total + item.product.price * item.quantity,
        0
    );

    return (
        <div className="app-shell">
            <Header cartCount={cartCount} onCartClick={() => setCartOpen(true)} />

            <main className="dashboard">
                <section className="welcome-panel">
                    <div className="welcome-copy">
                        <span className="eyebrow">THE CONSIDERED COLLECTION</span>
                        <h1>Good things,<br />well <em>chosen.</em></h1>
                        <p>A little corner for the things worth keeping close.</p>
                    </div>
                    <div className="welcome-stamp" aria-hidden="true">
                        <span>CURATED</span>
                        <strong>{String(products.length).padStart(2, "0")}</strong>
                        <span>OBJECTS</span>
                    </div>
                    <div className="welcome-note">EST. FOR EVERYDAY<br />USE &amp; ADMIRATION</div>
                </section>

                <section className="overview-row" aria-label="Collection overview">
                    <div className="overview-item">
                        <span className="overview-icon">✳</span>
                        <div><strong>{products.length}</strong><span>pieces in the collection</span></div>
                    </div>
                    <div className="overview-item">
                        <span className="overview-icon">◌</span>
                        <div><strong>{categories.length}</strong><span>thoughtful categories</span></div>
                    </div>
                    <div className="overview-caption">SMALL FINDS. BIG EVERYDAY ENERGY.</div>
                </section>

                <div className="content-columns">
                    <aside className="editor-column">
                        <div className="section-heading">
                            <span className="eyebrow">{selectedProduct ? "MAKE IT YOURS" : "ADD TO THE EDIT"}</span>
                            <span className="heading-index">{selectedProduct ? "02" : "01"}</span>
                        </div>
                        <ProductForm
                            key={selectedProduct?.id ?? "new"}
                            selectedProduct={selectedProduct}
                            onSave={handleSave}
                            onCancel={() => setSelectedProduct(null)}
                            saving={saving}
                        />
                        <div className="editor-aside-note">
                            <span>✳</span>
                            <p>Everyday essentials, selected with a little more intention.</p>
                        </div>
                    </aside>

                    <section className="collection-column">
                        <div className="section-heading collection-heading">
                            <div>
                                <span className="eyebrow">BROWSE THE GOOD STUFF</span>
                                <h2>The collection<span className="period">.</span></h2>
                            </div>
                            <span className="collection-count">{filteredProducts.length} ITEMS</span>
                        </div>

                        <SearchBar
                            filters={filters}
                            categories={categories}
                            onChange={updateFilters}
                        />

                        {error && (
                            <div className="notice notice-error" role="alert">
                                <span>{error}</span>
                                {error.startsWith("Unable to load products") && (
                                    <button className="text-button" onClick={() => loadProducts()}>
                                        Try again
                                    </button>
                                )}
                            </div>
                        )}

                        {loading ? (
                            <div className="loading-state" role="status">
                                <span className="loading-mark">✳</span>
                                <p>Loading products...</p>
                            </div>
                        ) : error.startsWith("Unable to load products") && products.length === 0 ? (
                            <div className="empty-state">
                                <span aria-hidden="true">!</span>
                                <h3>The collection is out of reach.</h3>
                                <p>Check your connection and try again.</p>
                            </div>
                        ) : (
                            <ProductList
                                products={visibleProducts}
                                totalResults={filteredProducts.length}
                                onEdit={setSelectedProduct}
                                onDelete={handleDelete}
                                onDetails={handleDetails}
                                onAddToCart={addToCart}
                                page={currentPage}
                                pageCount={pageCount}
                                onPageChange={setPage}
                            />
                        )}
                    </section>
                </div>
            </main>

            {(details || detailsLoading) && (
                <ProductDetails
                    product={details}
                    loading={detailsLoading}
                    onClose={closeDetails}
                    onAddToCart={addToCart}
                />
            )}

            {cartOpen && (
                <div className="drawer-backdrop" onClick={() => setCartOpen(false)}>
                    <aside
                        className="cart-drawer"
                        role="dialog"
                        aria-modal="true"
                        aria-labelledby="cart-title"
                        onClick={event => event.stopPropagation()}
                    >
                        <div className="drawer-heading">
                            <div>
                                <span className="eyebrow">SAVED FOR LATER</span>
                                <h2 id="cart-title">Your little basket</h2>
                            </div>
                            <button className="close-button" onClick={() => setCartOpen(false)} aria-label="Close basket">×</button>
                        </div>
                        {cartProducts.length === 0 ? (
                            <div className="cart-empty"><span>◌</span><p>Your basket is taking a quiet moment.</p></div>
                        ) : (
                            <>
                                <div className="cart-items">
                                    {cartProducts.map(({ id, quantity, product }) => (
                                        <div className="cart-item" key={id}>
                                            <div className="cart-item-copy">
                                                <strong>{product.name}</strong>
                                                <span>{product.category} · ₹{product.price.toLocaleString("en-IN")}</span>
                                            </div>
                                            <div className="quantity-control" aria-label={`${product.name} quantity`}>
                                                <button onClick={() => changeCartQuantity(id, -1)} aria-label="Decrease quantity">−</button>
                                                <span>{quantity}</span>
                                                <button onClick={() => changeCartQuantity(id, 1)} aria-label="Increase quantity">+</button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="cart-total"><span>Basket total</span><strong>₹{cartTotal.toLocaleString("en-IN")}</strong></div>
                                <p className="cart-footnote">A lovely choice. Checkout isn't connected just yet.</p>
                            </>
                        )}
                    </aside>
                </div>
            )}
        </div>
    );
}

export default App;
