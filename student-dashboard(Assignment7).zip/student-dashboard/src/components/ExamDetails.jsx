function ExamDetails({ examName, date, room }) {
  return (
    <div className="card">
      <h2>Examination Details</h2>

      <p>
        <strong>Exam:</strong> {examName}
      </p>

      <p>
        <strong>Date:</strong> {date}
      </p>

      <p>
        <strong>Room:</strong> {room}
      </p>
    </div>
  );
}

export default ExamDetails;