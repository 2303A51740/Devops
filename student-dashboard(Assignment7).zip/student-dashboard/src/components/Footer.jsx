function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 ABC College of Engineering. All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;