function Header() {
  return (
    <header className="header">
      <h1>ABC College of Engineering</h1>
      <p>Student Management System</p>
    </header>
  );
}

export default Header;