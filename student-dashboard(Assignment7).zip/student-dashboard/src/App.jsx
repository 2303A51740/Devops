import { useState } from "react";
import Header from "./components/header";
import StudentProfile from "./components/StudentProfile";
import SubjectList from "./components/SubjectList";
import Attendance from "./components/Attendance";
import ExamDetails from "./components/ExamDetails";
import StudentCard from "./components/StudentCard";
import Footer from "./components/Footer";
import "./App.css";

function App() {
  const [selectedStudent, setSelectedStudent] = useState(null);

  const student = {
    name: "Bhargav",
    rollNumber: "2303A51740",
    branch: "Computer Science and Engineering",
    year: "3rd Year"
  };

  const subjects = [
    "Data Mining",
    "Machine Learning",
    "Artificial Intelligence",
    "Web Technologies",
    "Augmented and Virtual Reality"
  ];

  const students = [
    {
      name: "Bhargav",
      rollNumber: "2303A51740",
      branch: "Computer Science and Engineering",
      year: "3rd Year",
      attendance: 82
    },
    {
      name: "Rahul",
      rollNumber: "2303A51741",
      branch: "Information Technology",
      year: "3rd Year",
      attendance: 68
    },
    {
      name: "Priya",
      rollNumber: "2303A51742",
      branch: "Computer Science and Engineering",
      year: "3rd Year",
      attendance: 91
    }
  ];

  const handleViewProfile = (student) => {
    setSelectedStudent(student);
  };

  return (
    <div className="app">
      <Header />

      <main className="container">
        <h1>Student Management Dashboard</h1>

        <div className="dashboard-grid">
          <StudentProfile
            name={student.name}
            rollNumber={student.rollNumber}
            branch={student.branch}
            year={student.year}
          />

          <SubjectList subjects={subjects} />

          <Attendance percentage={82} />

          <ExamDetails
            examName="Semester End Examination"
            date="20 September 2026"
            room="Room 305"
          />
        </div>

        <section className="students-section">
          <h2>Students</h2>

          <div className="student-grid">
            {students.map((student) => (
              <StudentCard
                key={student.rollNumber}
                student={student}
                onViewProfile={handleViewProfile}
              />
            ))}
          </div>
        </section>

        {selectedStudent && (
          <div className="profile-message">
            <h2>Selected Student</h2>

            <p>
              <strong>Name:</strong> {selectedStudent.name}
            </p>

            <p>
              <strong>Roll Number:</strong> {selectedStudent.rollNumber}
            </p>

            <p>
              <strong>Branch:</strong> {selectedStudent.branch}
            </p>

            <p>
              <strong>Year:</strong> {selectedStudent.year}
            </p>

            <p>
              <strong>Attendance:</strong> {selectedStudent.attendance}%
            </p>

            <p>
              <strong>Status:</strong>{" "}
              <span
                className={
                  selectedStudent.attendance >= 75
                    ? "eligible"
                    : "not-eligible"
                }
              >
                {selectedStudent.attendance >= 75
                  ? "Eligible"
                  : "Not Eligible"}
              </span>
            </p>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

export default App;