function Header({ cartCount }) {
  return (
    <header>
      <h2>Online Shopping</h2>
      <p>Cart Items: {cartCount}</p>
    </header>
  );
}

export default Header;