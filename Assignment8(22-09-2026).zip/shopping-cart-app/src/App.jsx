import { useState } from "react";
import Header from "./components/Header";
import ProductList from "./components/ProductList";
import Cart from "./components/Cart";
import Footer from "./components/Footer";
import laptop from "./assets/laptop.jpg";
import smartphone from "./assets/smartphone.jpg";
import headphones from "./assets/headphones.jpg";
import smartwatch from "./assets/smartwatch.jpg";

function App() {
  const products = [
    {
      id: 1,
      name: "Laptop",
      price: 55000,
      image: laptop
    },
    {
      id: 2,
      name: "Smartphone",
      price: 25000,
      image: smartphone
    },
    {
      id: 3,
      name: "Headphones",
      price: 2000,
      image: headphones
    },
    {
      id: 4,
      name: "Smart Watch",
      price: 5000,
      image: smartwatch
    }
  ];

  const [cart, setCart] = useState([]);

  function addToCart(product) {
    setCart([...cart, product]);
  }

  function removeFromCart(id) {
    setCart(cart.filter((product) => product.id !== id));
  }

  const total = cart.reduce(
    (sum, product) => sum + product.price,
    0
  );

  return (
    <>
      <Header cartCount={cart.length} />

      <h1>Welcome to Online Shopping</h1>

      <div className="main-content">
        <ProductList
          products={products}
          addToCart={addToCart}
        />

        <Cart
          cart={cart}
          removeFromCart={removeFromCart}
          total={total}
        />
      </div>

      <Footer />
    </>
  );
}

export default App;