function Header() {
  return (
    <header>
      <h1>ABC University</h1>
      <nav>
        <a href="#home">Home</a>
        <a href="#courses">Courses</a>
        <a href="#registration">Registration</a>
      </nav>
    </header>
  );
}

export default Header;