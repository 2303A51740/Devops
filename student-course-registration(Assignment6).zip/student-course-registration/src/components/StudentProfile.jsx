function StudentProfile() {
  return (
    <section>
      <h2>Student Profile</h2>
      <p><strong>Name:</strong> Bhargav</p>
      <p><strong>Student ID:</strong> STU001</p>
      <p><strong>Program:</strong> B.Tech Computer Science</p>
      <p><strong>Year:</strong> 3rd Year</p>
    </section>
  );
}

export default StudentProfile;