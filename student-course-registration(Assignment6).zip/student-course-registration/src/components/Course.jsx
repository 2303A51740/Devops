function Course({ course, onRegister }) {
  return (
    <div className="course">
      <h3>{course.name}</h3>
      <p>Department: {course.department}</p>
      <p>Instructor: {course.instructor}</p>
      <p>Credits: {course.credits}</p>

      <button onClick={() => onRegister(course)}>
        Register
      </button>
    </div>
  );
}

export default Course;