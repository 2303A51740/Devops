import Course from "./Course";

function CourseList({ courses, onRegister }) {
  return (
    <section id="courses">
      <h2>Available Courses</h2>

      {courses.map((course) => (
        <Course
          key={course.id}
          course={course}
          onRegister={onRegister}
        />
      ))}
    </section>
  );
}

export default CourseList;