import { useState } from "react";
import Footer from "./Components/Footer";
import Header from "./Components/Header";
import StudentProfile from "./Components/StudentProfile";
import CourseList from "./Components/CourseList";
import Registration from "./Components/Registration";

function App() {
  const courses = [
    {
      id: 1,
      name: "Data Structures",
      department: "CSE",
      instructor: "Dr. Kumar",
      credits: 4
    },
    {
      id: 2,
      name: "Database Management Systems",
      department: "CSE",
      instructor: "Dr. Ravi",
      credits: 3
    },
    {
      id: 3,
      name: "Computer Networks",
      department: "CSE",
      instructor: "Dr. Priya",
      credits: 3
    },
    {
      id: 4,
      name: "Operating Systems",
      department: "CSE",
      instructor: "Dr. Sharma",
      credits: 4
    }
  ];

  const [registeredCourses, setRegisteredCourses] = useState([]);

  const handleRegister = (course) => {
    if (!registeredCourses.some((item) => item.id === course.id)) {
      setRegisteredCourses([...registeredCourses, course]);
    }
  };
  const handleRemove = (id) => {
  setRegisteredCourses(
    registeredCourses.filter((course) => course.id !== id)
  );
};

 return (
  <div>
    <Header />

    <StudentProfile />

    <CourseList
      courses={courses}
      onRegister={handleRegister}
    />

    <Registration
      registeredCourses={registeredCourses}
      onRemove={handleRemove}
    />

    <Footer />
  </div>
);
}

export default App;