const express = require("express");

const app = express();
const PORT = 3000;

app.use(express.json());

app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

const patients = [
    {
        id: 1,
        name: "Rahul",
        age: 35,
        disease: "Fever"
    },
    {
        id: 2,
        name: "Priya",
        age: 28,
        disease: "Diabetes"
    },
    {
        id: 3,
        name: "Arjun",
        age: 45,
        disease: "Hypertension"
    }
];

app.get("/", (req, res) => {
    res.send("Welcome to Hospital Management API");
});

app.get("/patients", (req, res) => {
    res.json(patients);
});

app.post("/patients", (req, res) => {
    const { name, age, disease } = req.body;

    if (!name || !age || !disease) {
        return res.status(400).json({
            message: "Name, age and disease are required"
        });
    }

    const newPatient = {
        id: patients.length + 1,
        name: name,
        age: age,
        disease: disease
    };

    patients.push(newPatient);

    res.status(201).json(newPatient);
});

app.get("/patients/:id", (req, res) => {
    const id = parseInt(req.params.id);

    const patient = patients.find(p => p.id === id);

    if (!patient) {
        return res.status(404).json({
            message: "Patient not found"
        });
    }

    res.json(patient);
});

app.use((req, res) => {
    res.status(404).json({
        message: "Route not found"
    });
});

app.listen(PORT, () => {
    console.log(`Hospital Management API running at http://localhost:${PORT}`);
});